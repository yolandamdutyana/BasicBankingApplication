/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package basicbankingsystem;
import java.util.Scanner;
/**
 *
 * @author yolanda
 */
public class BasicBankingSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          
        Scanner sc = new Scanner(System.in);
        BankAccount account =  null;
        
       while (true) {
       
           System.out.println("""
                              
                              ===== Banking System =====
                              1. Create account
                              2. Deposit
                              3. Withdraw
                              4. Check Balance
                              5. Exit
                              Choose an option: """);
           
           int choice = sc.nextInt();
           sc.nextLine();
           
           //menu logic
           switch (choice) {
           
               case 1 -> { 
                   System.out.print("Enter account number: ");
                   String accountNumber = sc.nextLine();
                   System.out.print("Enter the account holder name: ");
                   String name = sc.nextLine();
                   System.out.print("Enter the initial balance: ");
                   double balance = sc.nextDouble();
                   account = new BankAccount(accountNumber, name, balance);
                   System.out.println("Account created successfully!");
                }
                   
               case 2 -> {
                   if (account != null){
                   
                       System.out.print("Enter the deposit amount: ");
                       double depositAmount = sc.nextDouble();
                       account.deposit(depositAmount);
                   } else {
                   
                       System.out.println("No account found. Create an account first");
                   }
                }
                   
               case 3 -> {
                   if (account != null) {
                       
                       System.out.print("Enter withdrawal amount: ");
                       double withdrawAmount = sc.nextDouble();
                       account.withdraw(withdrawAmount);
                   } else {
                   
                       System.out.println("No account found. Create an account first");
                   }
                }
                   
               case 4 -> {
                   if (account!= null){
                   
                       System.out.println("Current Balance: " + account.getBalance());
                   } else {
                   
                       System.out.println("No account found. Create an account first");
                   } 
                }
                   
               case 5 -> { 
                   System.out.println("Exiting the application...");
                   sc.close();
                   return;
                }
               default -> System.out.println("Invalid choice. Try again.");
           }
       }
    }
    
}


    

