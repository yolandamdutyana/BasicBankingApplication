/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package basicbankingsystem;

/**
 *
 * @author yolan
 */
public class BankAccount {
    

    private String accountNumber;
    private String accountHolderName;
    private double balance;      //double bc it's money
    
    public BankAccount (String accountNumber, String accountHolderName, double initialBalance){
    
        this.accountHolderName =  accountHolderName;
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
    }
    
    public void deposit (double amount){
    
        if(amount > 0) {
        
            //balance plus the amount deposited
            balance += amount;
            System.out.print("Deposited: " + amount);
            
        } else {
        
            System.out.print("Invalid desposit amount! ");
        }
    }
    
    public void withdraw(double amount) {
    
        if (amount > 0 && amount <= balance ){
        
            //balance minus the amount being withdrawn
            balance -= amount;
            System.out.print("Withdraw: " + amount);
            
        } else {
        
            System.out.print("Insufficient funds or invalid amount");
        }
    }
    
    public double getBalance(){
    
        return balance;
    }
} 
