/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package basicbankingsystem;

/**
 *
 * @author yolan
 */


//Inheritance allows you to reuse code by referencing behaviours and data of an object

public class SavingsAccount extends BankAccount {

    private double interestRate; 
    
    public SavingsAccount(String accountNumber, String accountHolderName, double initialBalance, double interestRate){
    
        //initializes the fields from the parent class 
        //MUST BE the first statement 
        super(accountNumber, accountHolderName, initialBalance);
        this.interestRate = interestRate;
    }
    
    public void addInterest (){
    
        double interest = getBalance() * ( interestRate / 100);
        deposit (interest);
        System.out.print ("Interest added: " + interest);
    }
}

